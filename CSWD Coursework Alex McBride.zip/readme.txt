Hi Jim,

There's no backend so just needs basic web server to run, I used Chrome Web Server during coding.

To login use:

Username: Jim
Password: password1

Thanks,

Alex